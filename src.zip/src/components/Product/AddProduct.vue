<template>
  <based-navbar />
  <based-add-product />
  <!-- <basedtest/> -->
</template>
<script>
import BasedAddProduct from "../Product/BasedAddProduct.vue";
// import Basedtest from "../components/BasedTest.vue"
export default {
  components: {
    BasedAddProduct,
    // Basedtest,
  },
};
</script>