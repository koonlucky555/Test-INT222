<template>
   <div class="px-6 ">
    <div class="grid grid-cols-3 gap-4 items-center mb-14 md:mb-16 xl:mb-20">
      <img src="../../assets/BrandLogo/hm-logo.png" class="w-4/12 mx-auto" />
      <img
        src="../../assets/BrandLogo/uniqlo-logo.png" class="w-3/12 mx-auto" />
      <img src="../../assets/BrandLogo/zara-logo.png" class="w-4/12 mx-auto" />
    </div>
     <!-- <hr style="height:2px;border-width:0; " class="bg-gray-300 "> -->
  </div>
</template>

<style scoped>
@font-face {
  font-family: "Barlow";
  src: url("../../fonts/Barlow-ExtraLight.ttf");
}
.Barlow {
  font-family: Barlow;
}
@font-face {
  font-family: "Barlow-Medium";
  src: url("../../fonts/Barlow-Medium.ttf");
}
.Barlow-Medium {
  font-family: Barlow-Medium;
}
</style>