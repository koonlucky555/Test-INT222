<template>
<div class="pt-24">
<h1 class="text-2xl md:text-4xl Barlow-Medium text-center uppercase md:mt-4 xl:mt-4 mb-8 md:mb-10 xl:mb-14">About Us</h1>
  <div
    class="
      grid grid-cols-1
      sm:grid-cols-2
      md:grid-cols-3
      xl:grid-cols-5
      gap-4
      
    "
  >
    <div></div>
    <!-- Lucky -->
    <div
      class="
        flex flex-col
        items-center
        justify-center
        bg-white
        p-4
        shadow
        rounded-lg
      "
    >
      <div
        class="
          inline-flex
          shadow-lg
          border border-gray-200
          rounded-full
          overflow-hidden
          h-40
          w-40
        "
      >
        <img src="../../assets/Member/lucky.png" alt="" class="h-full w-full" />
      </div>

      <h2 class="mt-4 font-bold text-xl">Kanokporn Buaycharoen</h2>
      <h6 class="mt-2 text-sm font-medium">Front-End</h6>

      <ul class="flex flex-row mt-4 space-x-2">
        <li>
          <a
            href=""
            class="
              flex
              items-center
              justify-center
              h-8
              w-8
              border
              rounded-full
              text-gray-800
              border-gray-800
            "
          >
            <i class="fab fa-facebook"></i>
          </a>
        </li>
        <li>
          <a
            href=""
            class="
              flex
              items-center
              justify-center
              h-8
              w-8
              border
              rounded-full
              text-gray-800
              border-gray-800
            "
          >
            <i class="fab fa-twitter"></i>
          </a>
        </li>
        <li>
          <a
            href=""
            class="
              flex
              items-center
              justify-center
              h-8
              w-8
              border
              rounded-full
              text-gray-800
              border-gray-800
            "
          >
            <i class="fab fa-instagram"></i>
          </a>
        </li>
      </ul>
    </div>
    <!-- Muk -->
    <div
      class="
        flex flex-col
        items-center
        justify-center
        bg-white
        p-4
        shadow
        rounded-lg
      "
    >
      <div
        class="
          inline-flex
          shadow-lg
          border border-gray-200
          rounded-full
          overflow-hidden
          h-40
          w-40
        "
      >
        <img src="../../assets/Member/muk.jpg" alt="" class="h-full w-full" />
      </div>

      <h2 class="mt-4 font-bold text-xl">Pacharaporn Kamsanong</h2>
      <h6 class="mt-2 text-sm font-medium">Database x Devops</h6>

      <ul class="flex flex-row mt-4 space-x-2">
        <li>
          <a
            href=""
            class="
              flex
              items-center
              justify-center
              h-8
              w-8
              border
              rounded-full
              text-gray-800
              border-gray-800
            "
          >
            <i class="fab fa-facebook"></i>
          </a>
        </li>
        <li>
          <a
            href=""
            class="
              flex
              items-center
              justify-center
              h-8
              w-8
              border
              rounded-full
              text-gray-800
              border-gray-800
            "
          >
            <i class="fab fa-twitter"></i>
          </a>
        </li>
        <li>
          <a
            href=""
            class="
              flex
              items-center
              justify-center
              h-8
              w-8
              border
              rounded-full
              text-gray-800
              border-gray-800
            "
          >
            <i class="fab fa-instagram"></i>
          </a>
        </li>
      </ul>
    </div>
    <!-- Benz -->
    <div
      class="
        flex flex-col
        items-center
        justify-center
        bg-white
        p-4
        shadow
        rounded-lg
      "
    >
      <div
        class="
          inline-flex
          shadow-lg
          border border-gray-200
          rounded-full
          overflow-hidden
          h-40
          w-40
        "
      >
        <img src="../../assets/Member/benz.jpg" />
      </div>

      <h2 class="mt-4 font-bold text-xl">Weeraphon Supachok</h2>
      <h6 class="mt-2 text-sm font-medium">Back-End</h6>

      <ul class="flex flex-row mt-4 space-x-2">
        <li>
          <a
            href=""
            class="
              flex
              items-center
              justify-center
              h-8
              w-8
              border
              rounded-full
              text-gray-800
              border-gray-800
            "
          >
            <i class="fab fa-facebook"></i>
          </a>
        </li>
        <li>
          <a
            href=""
            class="
              flex
              items-center
              justify-center
              h-8
              w-8
              border
              rounded-full
              text-gray-800
              border-gray-800
            "
          >
            <i class="fab fa-twitter"></i>
          </a>
        </li>
        <li>
          <a
            href=""
            class="
              flex
              items-center
              justify-center
              h-8
              w-8
              border
              rounded-full
              text-gray-800
              border-gray-800
            "
          >
            <i class="fab fa-instagram"></i>
          </a>
        </li>
      </ul>
    </div>
  </div>
</div>
</template>

<style scoped>
@font-face {
  font-family: "Barlow";
  src: url("../../fonts/Barlow-ExtraLight.ttf");
}
.Barlow {
  font-family: Barlow;
}
@font-face {
  font-family: "Barlow-Medium";
  src: url("../../fonts/Barlow-Medium.ttf");
}
.Barlow-Medium {
  font-family: Barlow-Medium;
}
</style>