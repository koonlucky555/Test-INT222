<template>
  <based-navbar/>
  <based-product />
</template>

<script>
import BasedProduct from "../components/Product/BasedProduct.vue";
export default {
  components: {
    BasedProduct,
  },
};
</script>

