<template>
  <based-navbar/>
  <based-team/>
</template>
<script>
import BasedTeam from '../components/Decorate/BasedTeam.vue'
export default {
  components:{
    BasedTeam,
  }
}
</script>